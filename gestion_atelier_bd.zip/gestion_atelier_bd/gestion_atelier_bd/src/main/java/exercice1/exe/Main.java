package exercice1.exe;

import java.util.Scanner;

import exercice1.exe.entities.Categorie;
import exercice1.exe.repositories.ITables;
import exercice1.exe.repositories.BD.CategorieRepository;
import exercice1.exe.services.CategorieService;
import exercice1.exe.services.CategorieServiceImpl;

public class Main {

    public static void main(String[] args) {
        ITables <Categorie> repository =new CategorieRepository();
        CategorieService categorieServiceImpl = new CategorieServiceImpl(repository);
        int choix;
        Scanner scanner = new Scanner(System.in);
        do {
            System.out.println("1-Ajout Categorie");
            System.out.println("2-Lister Categorie");
            System.out.println("3-Quitter");
            choix=scanner.nextInt();
            scanner.nextLine();
            switch (choix) {
                case 1:
                    System.out.println("Libelle");
                    Categorie categorie=new Categorie(scanner.nextLine());
                    System.out.println(categorieServiceImpl);
                    categorieServiceImpl.add(categorie);
                    break;
                case 2:
                    // programation fonctionnel
                    categorieServiceImpl.getAll().forEach(System.out::println);
                break;
                case 3:
                    System.out.println("id");
                    int id=scanner.nextInt();
                    System.out.println(categorieServiceImpl.show(id));
                break;
            
                default:
                    break;
            }
        } while (choix!=3);
    }
}