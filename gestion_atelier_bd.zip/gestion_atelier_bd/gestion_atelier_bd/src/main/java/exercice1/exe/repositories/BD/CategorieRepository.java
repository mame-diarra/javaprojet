// package exercice1.exe.repositories.BD;
// import java.sql.Connection;
// import java.sql.DriverManager;
// import java.sql.PreparedStatement;
// import java.sql.ResultSet;
// import java.sql.SQLException;
// import java.sql.Statement;
// import java.util.ArrayList;

// import exercice1.exe.entities.Categorie;
// import exercice1.exe.repositories.ITables;

public class Repository<Categorie> categorieRepository = new Repository<>("categorie_table");{

    
}
