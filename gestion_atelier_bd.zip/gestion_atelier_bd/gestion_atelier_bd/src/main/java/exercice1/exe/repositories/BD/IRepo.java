public class IRepo {
    
        int getId();
    
}
