public class Repository<T extends IRepo> {
    private static final String DB_URL = "jdbc:mysql://localhost:3306/l3ism";
    private static final String DB_USER = "root";
    private static final String DB_PASSWORD = "";
    private String tableName;

    public Repository(String tableName) {
        this.tableName = tableName;
    }

    private Connection getConnection() throws SQLException {
        return DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
    }

    public int delete(int id) {
        int rowsDeleted = 0;
        String sql = "DELETE FROM " + tableName + " WHERE id = ?";

        try (Connection conn = getConnection();
             PreparedStatement statement = conn.prepareStatement(sql)) {
            statement.setInt(1, id);
            rowsDeleted = statement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return rowsDeleted;
    }

    // ... les autres méthodes (insert, update, findAll, findById) restent les mêmes, mais utilisent tableName.
}
