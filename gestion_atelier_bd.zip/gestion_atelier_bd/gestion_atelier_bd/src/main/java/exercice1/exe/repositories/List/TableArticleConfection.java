package exercice1.exe.repositories.List;

import exercice1.exe.entities.ArticleConfection;
public class TableArticleConfection extends Table <ArticleConfection>{
   
}
