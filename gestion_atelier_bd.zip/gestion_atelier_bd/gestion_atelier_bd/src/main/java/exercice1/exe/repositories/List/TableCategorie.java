package exercice1.exe.repositories.List;

import exercice1.exe.entities.Categorie;

public class TableCategorie extends Table <Categorie>{

    
    
}
