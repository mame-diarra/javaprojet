package exercice1.exe.repositories.List;

import exercice1.exe.entities.Unite;

public class TableUnite extends Table<Unite>{


}
