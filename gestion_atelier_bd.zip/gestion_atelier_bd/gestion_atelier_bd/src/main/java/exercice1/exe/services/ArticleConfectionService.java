package exercice1.exe.services;
import exercice1.exe.entities.ArticleConfection;

public interface ArticleConfectionService extends IService<ArticleConfection>{
    
}
