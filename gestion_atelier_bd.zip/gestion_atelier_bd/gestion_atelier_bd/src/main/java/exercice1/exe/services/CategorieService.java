package exercice1.exe.services;


import exercice1.exe.entities.Categorie;

public interface CategorieService extends IService<Categorie>{
    
    
}
