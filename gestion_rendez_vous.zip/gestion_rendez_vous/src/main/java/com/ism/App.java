package com.ism;
import com.ism.entities.Medecin;
import com.ism.entities.Patient;
import com.ism.entities.RendezVous;
import com.ism.repositories.bd.MedecinRepository;
import com.ism.repositories.core.Database;
import com.ism.repositories.core.ITables;
import com.ism.repositories.bd.impl.MedecinRepositoryImpl;
import com.ism.repositories.bd.impl.PatientRepositoryImpl;
import com.ism.repositories.core.MySQLImpl;
import com.ism.services.MedecinServiceImpl;
import com.ism.services.RendezVousServiceImpl;

import java.util.Scanner;
import java.util.ArrayList;
import java.util.List;



public class App {
    public static void main(String[] args) {
        List<Patient> patients = new ArrayList<>();
        List<Doctor> doctors = new ArrayList<>();
        List<Appointment> appointments = new ArrayList<>();
       
        Database database=new MySQLImpl();
   
        
        ITables<Medecin> repository1=new MedecinRepositoryImpl();
        MedecinServiceImpl MedecinServiceImpl=new MedecinServiceImpl(repository1);
       int choix;
        Scanner scanner = new Scanner(System.in);

        while (true) {
            System.out.println("1 - Créer un patient");
            System.out.println("2 - Créer un médecin");
            System.out.println("3 - Planifier un rendez-vous");
            System.out.println("4 - Afficher les rendez-vous du jour");
            System.out.println("5 - Quitter");
            System.out.print("Choix : ");
            int choice = scanner.nextInt();
            scanner.nextLine(); // Consume the newline character

            switch (choice) {
                case 1:
                    System.out.print("Le nom complet du patient : ");
                    String patientName = scanner.nextLine();
                    patients.add(new Patient(patientName));
                    break;
                case 2:
                    System.out.print("Nom du médecin : ");
                    String doctorName = scanner.nextLine();
                    doctors.add(new Doctor(doctorName));
                    break;
                case 3:
                    System.out.print("Le nom du patient : ");
                    String patientNameInput = scanner.nextLine();
                    Patient patient = findPatientByName(patients, patientNameInput);
                    if (patient == null) {
                        System.out.println("Patient non trouver.");
                        continue;
                    }

                    System.out.print("Le nom complet du médecin : ");
                    String doctorNameInput = scanner.nextLine();
                    Doctor doctor = findDoctorByName(doctors, doctorNameInput);
                    if (doctor == null) {
                        System.out.println("Médecin non trouve.");
                        continue;
                    }

                    System.out.print("La date du rendez-vous : ");
                    String rvtDate = scanner.nextLine();
                    Appointment rv = new RV(patient, doctor, rvDate);
                    pt.addRv(rv);
                    rvs.add(rv);
                    break;
                case 4:
                    System.out.print("La date du jour : ");
                    String currentDate = scanner.nextLine();
                    displayrvsForDay(rvs, currentDate);
                    break;
                case 5:
                    System.out.println("A binentot !");
                    System.exit(0);
                default:
                    System.out.println("Le choix n'est pas valide veuillez ressayer ");
            }
        }
    }

    private static Patient findPatientByName(List<Patient> patients, String name) {
        for (Patient patient : patients) {
            if (patient.getName().equalsIgnoreCase(name)) {
                return patient;
            }
        }
        return null;
    }

    private static Doctor findDoctorByName(List<Doctor> doctors, String name) {
        for (Doctor doctor : doctors) {
            if (doctor.getName().equalsIgnoreCase(name)) {
                return doctor;
            }
        }
        return null;
    }

    private static void displayrvsForDay(List<Rv> rvs, String date) {
        System.out.println("Rendez-vous pour le " + date + " :");
        for (Rv rv : rv) {
            if (rv.getDate().equalsIgnoreCase(date)) {
                System.out.println("Patient : " + rv.getPatient().getName());
                System.out.println("Médecin : " + rv.getDoctor().getName());
                System.out.println();
            }
        }
    }
}
