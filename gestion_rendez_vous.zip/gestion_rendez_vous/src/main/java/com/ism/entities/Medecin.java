package com.ism.entities;


import lombok.*;

import java.util.ArrayList;

@Getter
@Setter
public class Medecin extends Personne {
    class Doctor {
     
        private List<RendezVous> rvs;
    
    }
  
    ArrayList<RendezVous> rvs = new ArrayList<>();

    public void addRv(Unite rv) {
        rvs.add(rv);
    }

    public List<Rendez> getRv() {
        return rv;
    }
   
    public Medecin() {
        super();
    }
    public Medecin(int id, String nomC) {
        super(id,nomC);
       
    }

    


    
   
}

