package com.ism.entities;

import lombok.Builder;


public class Patient extends Personne {

    //Constructeur
    public Patient() {
        super();
    }
    public Patient(int id, String nomC) {
        super(id,nomC);
    }
    public Patient(String nomC) {
        super(nomC);
    }


    //To string
    @Override
    public String toString() {
        return "Patient" + super.toString();
    }
}
