package com.ism.entities;

import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
@Getter
@Setter
@EqualsAndHashCode
@ToString
public abstract class Personne {
    protected int id;
    protected String nomC;
    protected static int nbr;

    public Personne() {

    }

    public AbstractEntity(int id, String nomC) {
        this.id = id;
        this.libelle = nomC;
    }
    public Personne( String libelle) {
        this.id=nbr++;
        this.libelle = libelle;
    }





}
