package com.ism.entities;

import lombok.Builder;


public class RendezVous extends Personne {
    private String date;
    
    

    //Constructeur
    public RendezVous() {
        super();
    }
    public RendezVous(int id, String nomC, date) {
        super(id, libelle, + date);
    }

    @Override
    public String toString() {
        return "RendezVous" + super.toString();
    }

}
