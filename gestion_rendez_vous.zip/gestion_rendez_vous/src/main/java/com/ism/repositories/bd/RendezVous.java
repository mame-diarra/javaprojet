package com.ism.repositories.bd;

import com.ism.entities.RendezVous;
import com.ism.repositories.core.ITables;

public interface RendezVousRepository extends ITables<RendezVous> {

}
