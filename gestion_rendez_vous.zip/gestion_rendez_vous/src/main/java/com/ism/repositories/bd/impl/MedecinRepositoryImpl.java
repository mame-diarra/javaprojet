package com.ism.repositories.bd.impl;


public class MedecinRepositoryImpl extends MySQLRepository<Medecin> {
    
    }

    
