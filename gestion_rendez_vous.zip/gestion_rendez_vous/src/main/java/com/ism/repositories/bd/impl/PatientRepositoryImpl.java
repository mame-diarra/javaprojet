package com.ism.repositories.bd.impl;



public class PatientRepositoryImpl implements PatientRepository {
    
    }
     