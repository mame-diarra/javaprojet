package com.ism.repositories.list;

import com.ism.entities.Medecin;

public class TableMedecins extends Table<Medecin> {

}
