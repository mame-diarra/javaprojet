package com.ism.repositories.list;

import com.ism.entities.Patient;

public class TablePatients extends Table<Patient> {


}
