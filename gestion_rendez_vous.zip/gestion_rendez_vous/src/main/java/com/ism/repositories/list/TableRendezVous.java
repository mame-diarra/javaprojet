package com.ism.repositories.list;

import com.ism.entities.RendezVous;

public class TableRendezVous extends Table<RendezVous> {

}
