package com.ism.services;

import com.ism.entities.Medecin;

public interface MedecinService extends IService<Medecin> {

}
