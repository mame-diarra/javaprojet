package com.ism.services;

import com.ism.entities.Medecin;
import com.ism.repositories.core.ITables;

import java.util.ArrayList;

public class MedecinServiceImpl implements MedecinService {

    private ITables<Medecin> medecinRepository;

    public MedecinServiceImpl(ITables<Medecin> medecinRepository) {
        this.medcinRepository = medcinRepository;
    }

    @Override
    public int add(Medecin medecin) {
        return medecinRepository.insert(medecin);
    }

    @Override
    public ArrayList<Medecin> getAll() {
        return medecinRepository.findAll();
    }

    @Override
    public int update(Medecin medecin) {
        return medecinRepository.update(medecin);
    }

    @Override
    public Patient show(int id) {
        return medecinRepository.findByID(id);
    }

    @Override
    public int remove(int id) {
        return medecinRepository.delete(id);
    }

    @Override
    public int[] remove(int[] ids) {
        return new int[0];
    }
}
