package com.ism.services;

import com.ism.entities.Patient;

public interface PatientService extends IService<Patient> {

}
