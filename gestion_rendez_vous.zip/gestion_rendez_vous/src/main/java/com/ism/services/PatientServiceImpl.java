package com.ism.services;

import com.ism.entities.Patient;
import com.ism.repositories.core.ITables;

import java.util.ArrayList;

public class PatientServiceImpl implements PatientService {

    private ITables<Patient> patientRepository;

    public PatientServiceImpl(ITables<Patient> patientRepository) {
        this.patientRepository = patientRepository;
    }

    @Override
    public int add(Patient patient) {
        return patientRepository.insert(patient);
    }

    @Override
    public ArrayList<Patient> getAll() {
        return patientRepository.findAll();
    }

    @Override
    public int update(Patient patient) {
        return patientRepository.update(patient);
    }

    @Override
    public Patient show(int id) {
        return patientRepository.findByID(id);
    }

    @Override
    public int remove(int id) {
        return patientRepository.delete(id);
    }

    @Override
    public int[] remove(int[] ids) {
        return new int[0];
    }
}
