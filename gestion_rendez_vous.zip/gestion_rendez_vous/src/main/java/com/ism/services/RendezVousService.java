package com.ism.services;

import com.ism.entities.RendezVous;

public interface RendezVousService extends IService<RendezVous> {
}
