package com.ism.services;

import com.ism.entities.RendezVous;
import com.ism.repositories.core.ITables;

import java.util.ArrayList;

public class RendezVousServiceImpl implements RendezVousService {

    private ITables<RendezVous> RendezVousRepository;
    
    public RendezVousServiceImpl(ITables<RendezVous> RendezVousRepository) {
        this.RendezVousRepository = categoriesRepository;
    }


    @Override
    public int add(RendezVous rendezvous) {
        return RendezVousRepository.insert(rendezvous);
    }

    @Override
    public ArrayList<RendezVous> getAll() {
        // TODO Auto-generated method stub
        return rendezvousRepository.findAll();
    }

    @Override
    public int update(RendezVous rendezvous) {
        return RendezVousRepository.update(rendezvous);

    }

    @Override
    public RendezVous show(int id) {
        return RendezVousRepository.findByID(id);
    }

    @Override
    public int remove(int id) {
        return RendezVousRepository.delete(id);
    }

    @Override
    public int[] remove(int[] ids) {
        int[] idsNotDelete=new int[ids.length];
        int n=0;
        for (int id = 0; id < ids.length; id++) {
            if (RendezVousRepository.delete(id)==0) {
                idsNotDelete[n++]=id;

            }
        }
        return idsNotDelete;
    }

}
